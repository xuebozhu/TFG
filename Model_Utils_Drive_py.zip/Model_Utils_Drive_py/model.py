import pandas as pd # Herramienta para tratamiento de datasets - crear, actualizar, borrar...
import numpy as np #Operaciones matemáticas con matrices
from sklearn.model_selection import train_test_split #Dividir datos de entrenamiento y testeo 
#Keras es un contenedor de alto nivel que opera junto a Tensorflow (Librería de Aprendizaje automático)
#El contenedor secuencial es una pila lineal de capas
from keras.models import Sequential
#Estrategia de optimización popular que utiliza gradiente descendiente
from keras.optimizers import Adam
#to save our model periodically as checkpoints for loading later
from keras.callbacks import ModelCheckpoint
#Que tipo de capas queremos para nuestro modelo
from keras.layers import Lambda, Conv2D, MaxPooling2D, Dropout, Dense, Flatten
#Clase de ayuda para definir la forma de entrada y generar imágenes de entrenamiento a la vista de las rutas de imagen y los ángulos de dirección
from utils import INPUT_SHAPE, batch_generator
#Para argumentos en la linea de comandos
import argparse
#Leer ficheros
import os

#para la depuración, permite resultados reproducibles (determinísticos) 
np.random.seed(0)


def load_data(args):
    """
    Cargar los datos de entrenamiento y dividirlo en conjunto 1)Entrenamiento y 2)Validacion
    """
    #lee el archivo CSV en una sola variable
    data_df = pd.read_csv(os.path.join(os.getcwd(), args.data_dir, 'driving_log.csv'), names=['center', 'left', 'right', 'steering', 'throttle', 'reverse', 'speed'])

    #dataframes, podemos seleccionar filas y columnas por sus nombres
    #almacenaremos las imágenes de las cámaras como input data
    X = data_df[['center', 'left', 'right']].values
    #y nuestros comandos de giro como output data
    y = data_df['steering'].values

	#Ahora dividimos los datos en entrenamiento (80), testing(20) y validacion Gracias a SCIKIT LEARN
    X_train, X_valid, y_train, y_valid = train_test_split(X, y, test_size=args.test_size, random_state=0)

    return X_train, X_valid, y_train, y_valid


def build_model(args):
    """
    NVIDIA model used
    Normalización de imagen para evitar la saturación y hacer que los degradados funcionen mejor.
    Convolution: 5x5, filter: 24, strides: 2x2, activation: ELU
    Convolution: 5x5, filter: 36, strides: 2x2, activation: ELU
    Convolution: 5x5, filter: 48, strides: 2x2, activation: ELU
    Convolution: 3x3, filter: 64, strides: 1x1, activation: ELU
    Convolution: 3x3, filter: 64, strides: 1x1, activation: ELU
    Drop out (0.5)
    Fully connected: neurons: 100, activation: ELU
    Fully connected: neurons: 50, activation: ELU
    Fully connected: neurons: 10, activation: ELU
    Fully connected: neurons: 1 (output)

    # the convolution layers are meant to handle feature engineering
    the fully connected layer for predicting the steering angle.
    dropout avoids overfitting
    ELU(Exponential linear unit) function takes care of the Vanishing gradient problem. 
    """
    model = Sequential()
    model.add(Lambda(lambda x: x/127.5-1.0, input_shape=INPUT_SHAPE))
    model.add(Conv2D(24, 5, 5, activation='elu', subsample=(2, 2)))
    model.add(Conv2D(36, 5, 5, activation='elu', subsample=(2, 2)))
    model.add(Conv2D(48, 5, 5, activation='elu', subsample=(2, 2)))
    model.add(Conv2D(64, 3, 3, activation='elu'))
    model.add(Conv2D(64, 3, 3, activation='elu'))
    model.add(Dropout(args.keep_prob))
    model.add(Flatten())
    model.add(Dense(100, activation='elu'))
    model.add(Dense(50, activation='elu'))
    model.add(Dense(10, activation='elu'))
    model.add(Dense(1))
    model.summary()

    return model


def train_model(model, args, X_train, X_valid, y_train, y_valid):
    """
    Entrenar el modelo
    """
    #Guarda el modelo después de cada iteración(epoch)
    #cantidad para monitorear, verbosidad, es decir, modo de registro (0 o 1),
    #si save_best_only = true, no se sobrescribirá el último mejor modelo de acuerdo con la cantidad monitoreada.
    #mode: one of {auto, min, max}. Si save_best_only=True, la decisión de sobrescribir el archivo de salvar actual 
	#se basa en la maximización o la minimización de la cantidad supervisada. Para val_acc, 
    #este debería ser max, para val_loss este deberia ser min, etc. En el modo automático, la dirección se deduce automáticamente 
    # del nombre de la cantidad supervisada.
    checkpoint = ModelCheckpoint('model-{epoch:03d}.h5',
                                 monitor='val_loss',
                                 verbose=0,
                                 save_best_only=args.save_best_only,
                                 mode='auto')

    #Calcula la diferencia entre el ángulo de giro esperado y el real
    #eleva al cuadrado la diferencia
    #sumar todas esas diferencias como tantos puntos de datos tengamos
    #divide por el numero de ellas
    #ese valor es nuestro ERROR CUADRATICO MEDIO! esto es lo que queremos minimizar via
    #descenso de gradiente
    model.compile(loss='mean_squared_error', optimizer=Adam(lr=args.learning_rate))

    #Se ajusta el modelo con los datos generados lote por lote por un generador de Python

	#El generador se ejecuta en paralelo al modelo, por eficiencia.
    #Por ejemplo, esto permite hacer en tiempo real el tratamiento de imagenes en CPU a la vez que entrena tu modelo en GPU en paralelo
	#así que reformamos nuestros datos en sus lotes apropiados y entrenamos a nuestro modelo simultáneamente
    model.fit_generator(batch_generator(args.data_dir, X_train, y_train, args.batch_size, True),
                        args.samples_per_epoch,
                        args.nb_epoch,
                        max_q_size=1,
                        validation_data=batch_generator(args.data_dir, X_valid, y_valid, args.batch_size, False),
                        nb_val_samples=len(X_valid),
                        callbacks=[checkpoint],
                        verbose=1)

#Para los argumentos por linea de comandos
def s2b(s):
    """
    Converts a string to boolean value
    """
    s = s.lower()
    return s == 'true' or s == 'yes' or s == 'y' or s == '1'


def main():
    """
    Load train/validation data set and train the model
    """
    parser = argparse.ArgumentParser(description='Behavioral Cloning Training Program')
    parser.add_argument('-d', help='data directory',        dest='data_dir',          type=str,   default='data')
    parser.add_argument('-t', help='test size fraction',    dest='test_size',         type=float, default=0.2)
    parser.add_argument('-k', help='drop out probability',  dest='keep_prob',         type=float, default=0.5)
    parser.add_argument('-n', help='number of epochs',      dest='nb_epoch',          type=int,   default=15)
    parser.add_argument('-s', help='samples per epoch',     dest='samples_per_epoch', type=int,   default=20000)
    parser.add_argument('-b', help='batch size',            dest='batch_size',        type=int,   default=40)
    parser.add_argument('-o', help='save best models only', dest='save_best_only',    type=s2b,   default='true')
    parser.add_argument('-l', help='learning rate',         dest='learning_rate',     type=float, default=1.0e-4)
    args = parser.parse_args()

    #print parameters
    print('-' * 30)
    print('Parameters')
    print('-' * 30)
    for key, value in vars(args).items():
        print('{:<20} := {}'.format(key, value))
    print('-' * 30)

    #load data
    data = load_data(args)
    #build model
    model = build_model(args)
    #train model on data, it saves as model.h5 
    train_model(model, args, *data)


if __name__ == '__main__':
    main()

