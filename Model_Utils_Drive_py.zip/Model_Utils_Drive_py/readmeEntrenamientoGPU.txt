Tecnologías utilizadas para entrenamiento con GPU:
-GPU: NVidia Geforce GTX 1050Ti
	-Cuda v8.0
	-Cudnn v6.0
	-Tensorflow-GPU 1.3.0